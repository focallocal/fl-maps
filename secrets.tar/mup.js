module.exports = {
  servers: {
    one: {
      host: '104.238.186.173',
      username: 'root',
      password: 'changemeplease413'
    }
  },
  app: {
    name: 'focallocal',
    path: './',
    docker: {
      image: 'abernix/meteord:node-8.4.0-base'
    },
    servers: {
      one: {}
    },
    buildOptions: {
      serverOnly: true
    },
    env: {
      ROOT_URL: 'http://brightertomorrowmap.org',
      MONGO_URL: 'mongodb://<dbuser>:<dbpassword>@ds247430.mlab.com:47430/fl-sleeper',
      PORT: 9000
    }
  },
};
